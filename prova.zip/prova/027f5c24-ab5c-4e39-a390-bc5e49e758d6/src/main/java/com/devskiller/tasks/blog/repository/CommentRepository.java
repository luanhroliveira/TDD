package com.devskiller.tasks.blog.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.devskiller.tasks.blog.model.dto.CommentDto;

public interface CommentRepository extends MongoRepository<CommentDto, String> {
}
