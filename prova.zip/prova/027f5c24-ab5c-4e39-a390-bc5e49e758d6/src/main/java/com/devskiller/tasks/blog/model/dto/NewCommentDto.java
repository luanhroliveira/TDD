package com.devskiller.tasks.blog.model.dto;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class NewCommentDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String postId;

	private String author;

	private String content;

	private String comment;

	public NewCommentDto() {

	}

	public NewCommentDto(CommentDto entity) {
		author = entity.getAuthor();
		comment = entity.getComment();
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getPostId() {
		return postId;
	}

	public void setPostId(String postId) {
		this.postId = postId;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
