package com.devskiller.tasks.blog.model.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.DBRef;

public class PostDto {

	private String title;

	private String content;

	private LocalDateTime creationDate;
	
	@DBRef(lazy = true)
	private List<CommentDto> comments = new ArrayList<>();

	public PostDto(String title, String content, LocalDateTime creationDate) {
		this.title = title;
		this.content = content;
		this.creationDate = creationDate;
	}

	public List<CommentDto> getComments() {
		return comments;
	}

	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}

	public LocalDateTime getCreationDate() {
		return creationDate;
	}
}
