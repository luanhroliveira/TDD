package com.devskiller.tasks.blog.model.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class CommentDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String comment;
	private String author;
	private LocalDateTime creationDate;

	public CommentDto() {

	}

	public CommentDto(String id, String comment, String author, LocalDateTime creationDate) {
		this.id = id;
		this.comment = comment;
		this.author = author;
		this.creationDate = creationDate;
	}

	public CommentDto(CommentDto entity) {
		id = entity.getId();
		comment = entity.getComment();
		author = entity.getAuthor();
		creationDate = entity.getCreationDate();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public LocalDateTime getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDateTime creationDate) {
		this.creationDate = creationDate;
	}

}
