package com.devskiller.tasks.blog.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devskiller.tasks.blog.model.Post;
import com.devskiller.tasks.blog.model.dto.CommentDto;
import com.devskiller.tasks.blog.model.dto.NewCommentDto;
import com.devskiller.tasks.blog.repository.CommentRepository;
import com.devskiller.tasks.blog.repository.PostRepository;

@Service
public class CommentService {

	@Autowired
	private PostRepository postRepository;

	@Autowired
	private CommentRepository commentRepository;

	/**
	 * Returns a list of all comments for a blog post with passed id.
	 *
	 * @param postId id of the post
	 * @return list of comments sorted by creation date descending - most recent
	 *         first
	 *
	 * @throws IllegalArgumentException if there is no blog post for passed postId
	 */
	@Transactional(readOnly = true)
	public List<CommentDto> getCommentsForPost(String postId) {
		Optional<Post> post = postRepository.findById(postId);
		List<CommentDto> comments = post.get().getComments();
		return comments;
	}

	/**
	 * Creates a new comment
	 *
	 * @param newCommentDto data of new comment
	 * @return id of the created comment
	 *
	 * @throws IllegalArgumentException if there is no blog post for passed
	 *                                  newCommentDto.postId
	 */
	@Transactional
	public String addComment(NewCommentDto newCommentDto) {
		Post post = postRepository.findById(newCommentDto.getPostId()).get();

		CommentDto comment = new CommentDto();
		comment.setAuthor(newCommentDto.getAuthor());
		comment.setComment(newCommentDto.getComment());
		post.getComments().add(comment);
		commentRepository.save(comment);

		return comment.getId();
	}
}
