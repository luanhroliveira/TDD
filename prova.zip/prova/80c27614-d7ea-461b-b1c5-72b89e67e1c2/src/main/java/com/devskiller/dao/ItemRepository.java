package com.devskiller.dao;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.devskiller.model.Item;

@Repository
@Transactional
public class ItemRepository {

	@PersistenceContext
	EntityManager entityManager;

	public Page<Item> findItems(PageRequest pageRequest) {
		// TODO: Implement me
		int pageNumber = pageRequest.getPageNumber();
		int pageSize = pageRequest.getCount();

		Query query = entityManager.createQuery("SELECT obj FROM Item obj");
		query.setFirstResult((pageNumber) * pageSize);
		query.setMaxResults(pageSize);

		@SuppressWarnings("unchecked")
		List<Item> items = query.getResultList();

		Query queryTotal = entityManager.createQuery("SELECT COUNT(obj.id) FROM Item obj");
		long countResult = (long) queryTotal.getSingleResult();
		int i = (int) countResult;
		return new Page<>(items, pageRequest.getPageNumber(), i);
	}

	public List<Item> findItemsWithAverageRatingLowerThan(Integer rating) {
		// TODO: Implement me
		Query query = entityManager.createQuery("SELECT obj FROM Item obj");
		@SuppressWarnings("unchecked")
		List<Item> itens = query.getResultList();
		return itens.stream().filter(x -> x.mediaRating() < rating).collect(Collectors.toList());
	}

}
