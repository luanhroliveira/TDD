package com.devskiller.audit.service;

import com.devskiller.audit.consumer.ProductOrderEvent;

public class ProductOrderEventProcessor {

    public void processEvent(ProductOrderEvent event) {

    }

}
